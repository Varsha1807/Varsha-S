class OldInterface {
    request() {
        return "Old Interface";
    }
}


class NewInterface {
    specificRequest() {
        return "New Interface";
    }
}


class Adapter {
    constructor(newInterface) {
        this.newInterface = newInterface;
    }

    request() {
        return this.newInterface.specificRequest();
    }
}


const oldInterface = new OldInterface();
console.log(oldInterface.request());

const newInterface = new NewInterface();
const adapter = new Adapter(newInterface);
console.log(adapter.request());