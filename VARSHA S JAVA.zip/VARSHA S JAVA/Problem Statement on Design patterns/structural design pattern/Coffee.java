class Coffee {
    cost() {
        return 5;
    }
}


class MilkDecorator {
    constructor(coffee) {
        this.coffee = coffee;
    }

    cost() {
        return this.coffee.cost() + 1;
    }
}

class SugarDecorator {
    constructor(coffee) {
        this.coffee = coffee;
    }

    cost() {
        return this.coffee.cost() + 0.5;
    }
}


let coffee = new Coffee();
console.log(`Cost: $${coffee.cost()}`);

coffee = new MilkDecorator(coffee);
console.log(`Cost with Milk: $${coffee.cost()}`);

coffee = new SugarDecorator(coffee);
console.log(`Cost with Milk and Sugar: $${coffee.cost()}`);