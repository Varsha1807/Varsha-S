class WeatherStation {
    constructor() {
        this.observers = [];
        this.temperature = 0;
    }

    addObserver(observer) {
        this.observers.push(observer);
    }

    removeObserver(observer) {
        this.observers = this.observers.filter(obs => obs !== observer);
    }

    notifyObservers() {
        for (let observer of this.observers) {
            observer.update(this.temperature);
        }
    }

    setTemperature(temp) {
        this.temperature = temp;
        this.notifyObservers();
    }
}


class WeatherApp {
    update(temp) {
        console.log(`WeatherApp: Temperature updated to ${temp}°C`);
    }
}

class WeatherWebsite {
    update(temp) {
        console.log(`WeatherWebsite: Temperature updated to ${temp}°C`);
    }
}


const weatherStation = new WeatherStation();
const weatherApp = new WeatherApp();
const weatherWebsite = new WeatherWebsite();

weatherStation.addObserver(weatherApp);
weatherStation.addObserver(weatherWebsite);

weatherStation.setTemperature(25);
weatherStation.setTemperature(30);