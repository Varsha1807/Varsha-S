class Notification {
    send(message) {}
}

class EmailNotification extends Notification {
    send(message) {
        console.log(`Sending Email: ${message}`);
    }
}

class SMSNotification extends Notification {
    send(message) {
        console.log(`Sending SMS: ${message}`);
    }
}

class PushNotification extends Notification {
    send(message) {
        console.log(`Sending Push Notification: ${message}`);
    }
}

class NotificationFactory {
    static createNotification(type) {
        switch (type) {
            case 'email':
                return new EmailNotification();
            case 'sms':
                return new SMSNotification();
            case 'push':
                return new PushNotification();
            default:
                throw new Error('Unknown notification type');
        }
    }
}


const emailNotification = NotificationFactory.createNotification('email');
emailNotification.send('Hello via Email!');

const smsNotification = NotificationFactory.createNotification('sms');
smsNotification.send('Hello via SMS!');

const pushNotification = NotificationFactory.createNotification('push');
pushNotification.send('Hello via Push!');