class Logger {
    constructor() {
        if (Logger.instance) {
            return Logger.instance;
        }
        this.logs = [];
        Logger.instance = this;
    }

    log(message) {
        this.logs.push(message);
        console.log(`LOG: ${message}`);
    }

    printLogCount() {
        console.log(`${this.logs.length} Logs`);
    }
}


const logger1 = new Logger();
logger1.log("First log");

const logger2 = new Logger();
logger2.log("Second log");

logger1.printLogCount(); 
logger2.printLogCount(); 